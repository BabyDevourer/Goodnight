//
//  ViewController.swift
//  Goodnight
//
//  Created by admin on 25/08/2024.
//

import UIKit

class ViewController: UIViewController {
    var imageIndex: Int = 1
    @IBOutlet weak var imgGoodnight: UIImageView!
    
    @IBAction func click(_ sender: UIButton) {
        if imageIndex >= 37{
            imageIndex = 1
        }else{
            imageIndex += 1
            updateImage()
            
        }
        updateImage()
    }
        
        
        
        func updateImage(){
            imgGoodnight.image = UIImage(named: "goodnight-images/goodnight\(imageIndex)")
            print("goodnight-images/goodnight\(imageIndex)")
        }
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            updateImage()
        }
        
        
    }
    
    // "images/goodnight" + String(imageIndex)
    //"images/goodnight\(imageIndex)"

